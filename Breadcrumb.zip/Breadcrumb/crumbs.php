<?php

/**
 * Plugin Name: Simple Breadcrumbs
 * Description: A simple WordPress breadcrumb plugin that works with shortcode.
 * Version: 1.0.0
 * Author: HighB33kay
 * Author URI: https://github.com/highB33kay
 */

add_action('init', function () {
    // Register the breadcrumb shortcode.
    add_shortcode('breadcrumb', function () {
        // Get the current post object.
        $post = get_queried_object();

        // Get the home page title.
        $home_title = get_option('blogname');

        // Get the breadcrumb trail.
        $breadcrumb = get_breadcrumb();

        // Build the breadcrumb HTML.
        $breadcrumb_html = '<ul class="breadcrumb">';

        foreach ($breadcrumb as $item) {
            $breadcrumb_html .= '<li><a href="' . esc_url($item['url']) . '">' . esc_html($item['title']) . '</a></li>';
        }

        $breadcrumb_html .= '</ul>';

        // Return the breadcrumb HTML.
        return $breadcrumb_html;
    });
});

// enqueue style
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('breadcrumb', plugin_dir_url(__FILE__) . 'style.css');
});

/**
 * Get the breadcrumb trail.
 *
 * @return array
 */
function get_breadcrumb()
{
    // Get the current post object.
    $post = get_queried_object();

    // Create an empty breadcrumb array.
    $breadcrumb = array();

    // Add the home page to the breadcrumb.
    $breadcrumb[] = array(
        'title' => $home_title,
        'url'   => home_url('/')
    );

    // Add the current post to the breadcrumb.
    if ($post) {
        $breadcrumb[] = array(
            'title' => $post->post_title,
            'url'   => get_permalink($post->ID)
        );
    }

    return $breadcrumb;
}

// Change the breadcrumb separator.

add_filter('breadcrumb_separator', function ($separator) {
    return '/';
});
